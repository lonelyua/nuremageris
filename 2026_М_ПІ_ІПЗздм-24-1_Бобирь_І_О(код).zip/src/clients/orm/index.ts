import { PrismaClient, Prisma } from '@prisma/client'
import { dbConfig } from '../../../configs/db'
import type {
  DbAdapter, User, OrderWithDetails, OrderWithItems, UserOrderTotal, LastOrderPerUser,
  Order, ListUsersFilters, SortOptions, PageOptions, NewOrderInput,
  ProductSalesReport, MonthlyRevenue,
} from '../../types'

const ALLOWED_SORT_FIELDS = new Set(['id', 'name', 'email', 'created_at'])

export class PrismaAdapter implements DbAdapter {
  private readonly prisma: PrismaClient

  constructor() {
    // Prisma pool params are passed via URL query string (all timeout values in seconds).
    // connection_limit = max pool size (matches pool.max for all adapters).
    // pool_timeout     = wait for a free connection from the pool (≈ knex acquireTimeoutMillis).
    // connect_timeout  = TCP connection establishment timeout (≈ pg connectionTimeoutMillis).
    // NOTE: Prisma URL does not expose min connections or idle_timeout.
    //       min is effectively 0 (lazy); warmup iterations pre-warm the pool before measurement.
    const timeoutSec = Math.max(1, Math.ceil(dbConfig.pool.connectionTimeoutMs / 1000))
    const url =
      `postgresql://${dbConfig.user}:${dbConfig.password}` +
      `@${dbConfig.host}:${dbConfig.port}/${dbConfig.database}` +
      `?connection_limit=${dbConfig.pool.max}&pool_timeout=${timeoutSec}&connect_timeout=${timeoutSec}`
    this.prisma = new PrismaClient({ log: [], datasources: { db: { url } } })
  }

  // ------------------------------------------------------------------
  // Read – simple
  // ------------------------------------------------------------------

  async findUserById(id: number): Promise<User | null> {
    return this.prisma.user.findUnique({ where: { id } }) as Promise<User | null>
  }

  async findUserByEmail(email: string): Promise<User | null> {
    return this.prisma.user.findUnique({ where: { email } }) as Promise<User | null>
  }

  async listUsers(filters: ListUsersFilters, sort: SortOptions, page: PageOptions): Promise<User[]> {
    const where: Prisma.UserWhereInput = {}
    if (filters.createdAfter) where.created_at = { gt: filters.createdAfter }
    if (filters.search)       where.name = { contains: filters.search, mode: 'insensitive' }

    const orderByField = ALLOWED_SORT_FIELDS.has(sort.field) ? sort.field : 'id'

    return this.prisma.user.findMany({
      where,
      orderBy: { [orderByField]: sort.dir },
      take:    page.limit,
      skip:    (page.page - 1) * page.limit,
    }) as Promise<User[]>
  }

  // ------------------------------------------------------------------
  // Read – medium
  // ------------------------------------------------------------------

  async getOrderWithDetails(orderId: number): Promise<OrderWithDetails | null> {
    const row = await this.prisma.order.findUnique({
      where:   { id: orderId },
      include: {
        user:  { select: { id: true, email: true, name: true } },
        items: { include: { product: { select: { name: true } } } },
      },
    })
    if (!row) return null

    return {
      order: {
        id:         row.id,
        user_id:    row.user_id,
        status:     row.status,
        total:      row.total.toString(),
        created_at: row.created_at,
      },
      user: row.user,
      items: row.items.map(item => ({
        id:           item.id,
        order_id:     item.order_id,
        product_id:   item.product_id,
        quantity:     item.quantity,
        unit_price:   item.unit_price.toString(),
        product_name: item.product.name,
      })),
    }
  }

  async getUserOrderTotals(limit = 20): Promise<UserOrderTotal[]> {
    // GROUP BY + aggregation — not expressible in Prisma fluent API, use raw SQL
    return this.prisma.$queryRaw<UserOrderTotal[]>(Prisma.sql`
      SELECT
        u.id                                    AS user_id,
        u.name                                  AS user_name,
        COUNT(o.id)::int                        AS order_count,
        COALESCE(SUM(o.total), 0)::text         AS total_spent
      FROM users u
      LEFT JOIN orders o ON o.user_id = u.id
      GROUP BY u.id, u.name
      ORDER BY COALESCE(SUM(o.total), 0) DESC
      LIMIT ${limit}
    `)
  }

  // ------------------------------------------------------------------
  // Read – heavy
  // ------------------------------------------------------------------

  async getLastOrderPerUser(limit = 20): Promise<LastOrderPerUser[]> {
    // Window function — not supported in Prisma fluent API, use raw SQL
    return this.prisma.$queryRaw<LastOrderPerUser[]>(Prisma.sql`
      SELECT
        ranked.user_id,
        u.email                       AS user_email,
        ranked.last_order_id,
        ranked.last_order_total::text AS last_order_total,
        ranked.last_order_at
      FROM (
        SELECT
          o.id          AS last_order_id,
          o.user_id,
          o.total       AS last_order_total,
          o.created_at  AS last_order_at,
          ROW_NUMBER() OVER (PARTITION BY o.user_id ORDER BY o.created_at DESC) AS rn
        FROM orders o
      ) ranked
      JOIN users u ON u.id = ranked.user_id
      WHERE ranked.rn = 1
      ORDER BY ranked.last_order_at DESC
      LIMIT ${limit}
    `)
  }

  async batchGetUsers(ids: number[]): Promise<User[]> {
    if (ids.length === 0) return []
    return this.prisma.user.findMany({ where: { id: { in: ids } } }) as Promise<User[]>
  }

  // ------------------------------------------------------------------
  // Read – deep join (Prisma generates 6 separate SELECT queries;
  //         raw/knex/dal use a single JOIN query — key differentiator)
  // ------------------------------------------------------------------

  async getTopOrdersWithItems(limit: number): Promise<OrderWithItems[]> {
    const orders = await this.prisma.order.findMany({
      take:    limit,
      orderBy: { created_at: 'desc' },
      include: {
        user:  { select: { id: true, email: true, name: true } },
        items: {
          include: {
            product: {
              include: { category: { select: { name: true } } },
            },
          },
        },
        payment: true,
      },
    })

    return orders.map(o => ({
      order: {
        id:         o.id,
        user_id:    o.user_id,
        status:     o.status,
        total:      o.total.toString(),
        created_at: o.created_at,
      },
      user: o.user,
      items: o.items.map(it => ({
        id:            it.id,
        order_id:      it.order_id,
        product_id:    it.product_id,
        quantity:      it.quantity,
        unit_price:    it.unit_price.toString(),
        product_name:  it.product.name,
        category_name: it.product.category.name,
      })),
      payment: o.payment
        ? {
            id:       o.payment.id,
            order_id: o.payment.order_id,
            amount:   o.payment.amount.toString(),
            status:   o.payment.status,
            paid_at:  o.payment.paid_at,
          }
        : null,
    }))
  }

  // ------------------------------------------------------------------
  // Analytics (GROUP BY / window functions — all via $queryRaw)
  // ------------------------------------------------------------------

  async getProductSalesReport(): Promise<ProductSalesReport[]> {
    return this.prisma.$queryRaw<ProductSalesReport[]>(Prisma.sql`
      SELECT
        c.id                                                         AS category_id,
        c.name                                                       AS category_name,
        COUNT(DISTINCT p.id)::int                                    AS product_count,
        ROUND(AVG(p.price), 2)::text                                 AS avg_price,
        COALESCE(SUM(p.stock), 0)::int                               AS total_stock,
        COUNT(DISTINCT oi.order_id)::int                             AS orders_count,
        COALESCE(SUM(oi.quantity * oi.unit_price), 0)::text          AS revenue
      FROM categories c
      LEFT JOIN products p     ON p.category_id = c.id
      LEFT JOIN order_items oi ON oi.product_id = p.id
      GROUP BY c.id, c.name
      ORDER BY COALESCE(SUM(oi.quantity * oi.unit_price), 0) DESC
    `)
  }

  async getMonthlyRevenueTrend(months: number): Promise<MonthlyRevenue[]> {
    return this.prisma.$queryRaw<MonthlyRevenue[]>(Prisma.sql`
      WITH monthly AS (
        SELECT
          EXTRACT(YEAR  FROM created_at)::int AS year,
          EXTRACT(MONTH FROM created_at)::int AS month,
          COUNT(*)::int                        AS order_count,
          SUM(total)::text                     AS revenue
        FROM orders
        WHERE created_at >= NOW() - INTERVAL '1 month' * ${months}
        GROUP BY year, month
      )
      SELECT
        year, month, order_count, revenue,
        SUM(revenue::numeric) OVER (ORDER BY year, month)::text AS running_total
      FROM monthly
      ORDER BY year, month
    `)
  }

  // ------------------------------------------------------------------
  // Write
  // ------------------------------------------------------------------

  async insertOneUser(data: { email: string; name: string }): Promise<User> {
    return this.prisma.user.create({ data }) as Promise<User>
  }

  async insertManyProducts(
    data: Array<{ categoryId: number; name: string; price: number; stock: number }>
  ): Promise<number> {
    if (data.length === 0) return 0
    const result = await this.prisma.product.createMany({
      data: data.map(d => ({
        category_id: d.categoryId,
        name:        d.name,
        price:       d.price,
        stock:       d.stock,
      })),
    })
    return result.count
  }

  async createOrderWithItems(data: NewOrderInput): Promise<Order> {
    const row = await this.prisma.$transaction(async trx => {
      return trx.order.create({
        data: {
          user_id: data.userId,
          status:  'pending',
          total:   data.paymentAmount,
          items: {
            create: data.items.map(it => ({
              product_id: it.productId,
              quantity:   it.quantity,
              unit_price: it.unitPrice,
            })),
          },
          payment: {
            create: { amount: data.paymentAmount, status: 'pending' },
          },
        },
      })
    })

    return {
      id:         row.id,
      user_id:    row.user_id,
      status:     row.status,
      total:      row.total.toString(),
      created_at: row.created_at,
    }
  }

  // ------------------------------------------------------------------
  // Write – bulk transactional (per-row INSERT vs raw/knex batch INSERT)
  // Prisma creates each order_item individually → N×items more round-trips
  // ------------------------------------------------------------------

  async bulkCreateOrders(orders: NewOrderInput[]): Promise<Order[]> {
    if (orders.length === 0) return []
    return this.prisma.$transaction(async trx => {
      const results: Order[] = []

      for (const data of orders) {
        const row = await trx.order.create({
          data: {
            user_id: data.userId,
            status:  'pending',
            total:   data.paymentAmount,
            items: {
              create: data.items.map(it => ({
                product_id: it.productId,
                quantity:   it.quantity,
                unit_price: it.unitPrice,
              })),
            },
            payment: {
              create: { amount: data.paymentAmount, status: 'pending' },
            },
          },
        })

        results.push({
          id:         row.id,
          user_id:    row.user_id,
          status:     row.status,
          total:      row.total.toString(),
          created_at: row.created_at,
        })
      }

      return results
    })
  }

  // ------------------------------------------------------------------
  // Update / Delete
  // ------------------------------------------------------------------

  async updateOrderStatus(orderId: number, status: string): Promise<boolean> {
    try {
      await this.prisma.order.update({ where: { id: orderId }, data: { status } })
      return true
    } catch (e) {
      if (e instanceof Prisma.PrismaClientKnownRequestError && e.code === 'P2025') return false
      throw e
    }
  }

  async deleteOrder(orderId: number): Promise<boolean> {
    try {
      await this.prisma.order.delete({ where: { id: orderId } })
      return true
    } catch (e) {
      if (e instanceof Prisma.PrismaClientKnownRequestError && e.code === 'P2025') return false
      throw e
    }
  }

  // ------------------------------------------------------------------
  // Lifecycle
  // ------------------------------------------------------------------

  async close(): Promise<void> {
    await this.prisma.$disconnect()
  }
}
